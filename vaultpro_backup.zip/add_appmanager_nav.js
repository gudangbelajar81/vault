﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/DashboardLayout.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('App Manager')) {
  // Add AppManager link between Workspace and Radar
  const newNavItem = `  { to: '/workspace', icon: LayoutPanelLeft, label: 'Kubah', activeColor: 'text-indigo-400', glow: 'shadow-indigo-500/20' },
  { to: '/apps', icon: Library, label: 'App Manager', activeColor: 'text-indigo-400', glow: 'shadow-indigo-500/20' },`;
  
  content = content.replace("{ to: '/workspace', icon: LayoutPanelLeft, label: 'Kubah', activeColor: 'text-indigo-400', glow: 'shadow-indigo-500/20' },", newNavItem);
  
  fs.writeFileSync(file, content, 'utf8');
}
