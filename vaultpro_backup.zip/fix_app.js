﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('import { Workspace }')) {
  content = content.replace("import { KnowledgeBase } from './pages/KnowledgeBase';", "import { KnowledgeBase } from './pages/KnowledgeBase';\nimport { Workspace } from './pages/Workspace';");
  
  content = content.replace("<Route path=\"knowledge\" element={<KnowledgeBase />} />", "<Route path=\"knowledge\" element={<KnowledgeBase />} />\n            <Route path=\"workspace\" element={<Workspace />} />");
  
  fs.writeFileSync(file, content, 'utf8');
}
