﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/Courses.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(
  "        comms = [{ id: Date.now().toString() + 'c1', url: '' }];\n      }\n  \n      setFormData({",
  "        comms = [{ id: Date.now().toString() + 'c1', url: '' }];\n      }\n  \n      let eLinks = dec.extraLinks || [];\n      if (eLinks.length === 0) {\n        eLinks = [{ id: Date.now().toString() + 'e1', name: '', url: '' }];\n      }\n\n      setFormData({"
);

fs.writeFileSync(file, content, 'utf8');
