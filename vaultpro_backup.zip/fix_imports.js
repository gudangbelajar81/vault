﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/components/SmartNotepad.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("import { decryptData } from '../utils/encryption';", "import { decryptData } from '../utils/crypto';");
content = content.replace("const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';", "import { API_URL } from '../config';");

fs.writeFileSync(file, content, 'utf8');
