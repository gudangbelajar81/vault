﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/components/SmartNotepad.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));", "if (!masterPassword) return { groqKey: '', openRouterKey: '', geminiKey: '' };\n              const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));");

fs.writeFileSync(file, content, 'utf8');
