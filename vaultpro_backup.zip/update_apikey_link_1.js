﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/ApiKeys.tsx';
let content = fs.readFileSync(file, 'utf8');

// 1. Update ApiItem Interface
content = content.replace('key: string;\n  }', 'key: string;\n    url?: string;\n  }');

// 2. Update viewApis.push logic
const oldViewApisPush = "viewApis.push({ id: api.id || Date.now().toString() + Math.random(), name: api.name || 'API', key: api.key || '' });";
const newViewApisPush = "viewApis.push({ id: api.id || Date.now().toString() + Math.random(), name: api.name || 'API', key: api.key || '', url: api.url || '' });";
content = content.replace(oldViewApisPush, newViewApisPush);
// Update type of viewApis
content = content.replace("let viewApis: { id: string, name: string, key: string }[] = [];", "let viewApis: { id: string, name: string, key: string, url?: string }[] = [];");

// 3. Update viewApis.map rendering to include ExternalLink button if url exists
const oldCardRender = `                            <button 
                              onClick={() => copyToClipboard(api.key, 'API Key')}
                              className="text-text-muted hover:text-primary p-1"
                            >
                              <Copy size={14} />
                            </button>
                          </div>`;
const newCardRender = `                            <button 
                              onClick={() => copyToClipboard(api.key, 'API Key')}
                              className="text-text-muted hover:text-primary p-1"
                            >
                              <Copy size={14} />
                            </button>
                            {api.url && (
                              <a 
                                href={api.url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-text-muted hover:text-primary p-1 ml-1 border-l border-border/50 pl-2"
                              >
                                <ExternalLink size={14} />
                              </a>
                            )}
                          </div>`;
content = content.replace(oldCardRender, newCardRender);

// 4. Update Form Inputs
// We need to find the form where `api.name` and `api.key` are rendered, and add the `api.url` input.
const formInputBlock = `<div className="col-span-5 md:col-span-5">
                                  <input type="text" placeholder="Nama API"
                                  value={api.name}`;

// We will change the form layout slightly to fit 3 inputs (Name, Key, URL).
// Currently it's flex flex-col md:flex-row gap-1 items-end
// Inside, there's col-span-5 (Name) and col-span-12 md:col-span-6 (Key). We can change them to flex-1 or specific widths.
