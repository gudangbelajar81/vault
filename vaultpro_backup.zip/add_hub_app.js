﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('import { IntelligenceHub }')) {
  content = content.replace("import { Workspace } from './pages/Workspace';", "import { Workspace } from './pages/Workspace';\nimport { IntelligenceHub } from './pages/IntelligenceHub';");
}

if (!content.includes('<Route path="/intelligence"')) {
  content = content.replace('<Route path="/workspace" element={<Workspace />} />', '<Route path="/workspace" element={<Workspace />} />\n            <Route path="/intelligence" element={<IntelligenceHub />} />');
}

fs.writeFileSync(file, content, 'utf8');
