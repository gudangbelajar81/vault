﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('import { AppManager }')) {
  content = content.replace("import { IntelligenceHub } from './pages/IntelligenceHub';", "import { IntelligenceHub } from './pages/IntelligenceHub';\nimport { AppManager } from './pages/AppManager';");
}

if (!content.includes('<Route path="/apps"')) {
  content = content.replace('<Route path="/intelligence" element={<IntelligenceHub />} />', '<Route path="/intelligence" element={<IntelligenceHub />} />\n            <Route path="/apps" element={<AppManager />} />');
}

fs.writeFileSync(file, content, 'utf8');
