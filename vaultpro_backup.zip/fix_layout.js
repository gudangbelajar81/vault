﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/DashboardLayout.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("Library, RefreshCw } from 'lucide-react';", "Library, RefreshCw, LayoutPanelLeft } from 'lucide-react';");

const newNavItem = `  { to: '/knowledge', icon: Library, label: 'Pustaka', activeColor: 'text-rose-400', glow: 'shadow-rose-500/20' },
  { to: '/workspace', icon: LayoutPanelLeft, label: 'Meja Kerja', activeColor: 'text-indigo-400', glow: 'shadow-indigo-500/20' },`;

content = content.replace("{ to: '/knowledge', icon: Library, label: 'Pustaka', activeColor: 'text-rose-400', glow: 'shadow-rose-500/20' },", newNavItem);

fs.writeFileSync(file, content, 'utf8');
