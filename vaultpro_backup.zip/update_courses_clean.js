﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/Courses.tsx';
let content = fs.readFileSync(file, 'utf8');

// 1. Add extraLinks to formData initial state
content = content.replace(
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n    notes: '',",
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n    extraLinks: [{ id: Date.now().toString() + 'e1', name: '', url: '' }],\n    notes: '',"
);

// 2. Add extraLinks to resetForm
content = content.replace(
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n      notes: ''",
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n      extraLinks: [{ id: Date.now().toString() + 'e1', name: '', url: '' }],\n      notes: ''"
);

// 3. Add extraLinks to dataToEncrypt in handleSave
content = content.replace(
  "communities: formData.communities.filter(c => c.url),\n        notes: formData.notes",
  "communities: formData.communities.filter(c => c.url),\n        extraLinks: formData.extraLinks ? formData.extraLinks.filter(e => e.url) : [],\n        notes: formData.notes"
);

// 4. Update handleEdit (openEdit)
// Insert eLinks parsing logic right before setFormData
const openEditRegex = /(let comms = dec\.communities \|\| \[\];.*?setFormData\(\{)/s;
content = content.replace(openEditRegex, (match) => {
  return match.replace(
    'setFormData({',
    `let eLinks = dec.extraLinks || [];\n    if (eLinks.length === 0) {\n      eLinks = [{ id: Date.now().toString() + 'e1', name: '', url: '' }];\n    }\n\n    setFormData({`
  );
});

// Insert extraLinks: eLinks inside setFormData in handleEdit
content = content.replace(
  "communities: comms,\n      notes: dec.notes || '',",
  "communities: comms,\n      extraLinks: eLinks,\n      notes: dec.notes || '',"
);

// 5. Add UI logic before notes
const uiCode = `               </div>

                <div className="bg-black/5 dark:bg-black/20 border border-border/50 rounded-xl p-2 space-y-2">
                   <h4 className="text-[9px] font-bold text-emerald-400 uppercase tracking-wider mb-1.5 flex items-center gap-1"><ExternalLink size={12}/> 5. Link Tambahan</h4>
                   
                   <div className="space-y-1">
                      {formData.extraLinks && formData.extraLinks.map((el, idx) => (
                        <div key={el.id} className="flex gap-1 items-end">
                          <div className="flex-1 flex flex-col md:flex-row gap-1">
                            <input 
                              type="text" value={el.name}
                              onChange={e => {
                                 const newLinks = [...formData.extraLinks];
                                 newLinks[idx].name = e.target.value;
                                 setFormData({...formData, extraLinks: newLinks});
                              }}
                              placeholder="Nama Link (Opsional)"
                              className="w-full md:w-1/3 bg-surface/50 border border-border rounded-lg px-2 py-1 text-[11px] text-text-primary focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                            />
                            <input 
                              type="url" value={el.url}
                              onChange={e => {
                                 const newLinks = [...formData.extraLinks];
                                 newLinks[idx].url = e.target.value;
                                 setFormData({...formData, extraLinks: newLinks});
                              }}
                              placeholder="Link URL (https://...)"
                              className="w-full md:w-2/3 bg-surface/50 border border-border rounded-lg px-2 py-1 text-[11px] text-text-primary focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                            />
                          </div>
                          <button 
                            type="button"
                            onClick={() => window.open(el.url.startsWith('http') ? el.url : \`https://\${el.url}\`, '_blank')}
                            disabled={!el.url}
                            className="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-500 h-[26px] px-3 rounded-lg transition-colors shrink-0 flex items-center justify-center gap-1 text-[10px] font-medium disabled:opacity-50"
                          >
                            <ExternalLink size={12} />
                          </button>
                          {formData.extraLinks.length > 1 && (
                            <button 
                              type="button" onClick={() => setFormData({...formData, extraLinks: formData.extraLinks.filter(x => x.id !== el.id)})}
                              className="bg-danger/10 hover:bg-danger/20 border border-danger/20 text-danger h-[26px] px-2.5 rounded-lg transition-colors shrink-0 flex items-center justify-center"
                            >
                              <X size={12} />
                            </button>
                          )}
                        </div>
                      ))}
                      
                      <button 
                        type="button" onClick={() => setFormData({...formData, extraLinks: [...(formData.extraLinks || []), { id: Date.now().toString(), name: '', url: '' }]})}
                        className="mt-2 w-fit border border-dashed border-emerald-500/40 hover:border-emerald-500/80 text-emerald-500 bg-transparent hover:bg-emerald-500/10 px-3 py-1 rounded-lg transition-colors text-[10px] font-medium flex items-center gap-1"
                      >
                        <Plus size={10} /> Tambah Link
                      </button>
                   </div>
                </div>\n`;

const anchor = `<label className="text-[10px] font-bold text-text-secondary uppercase tracking-wider block mb-1">Catatan Tambahan</label>`;
content = content.replace(anchor, uiCode + anchor);

fs.writeFileSync(file, content, 'utf8');
