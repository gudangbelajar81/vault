﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace('<Route path="/knowledge" element={<KnowledgeBase />} />', '<Route path="/knowledge" element={<KnowledgeBase />} />\n          <Route path="/workspace" element={<Workspace />} />');

fs.writeFileSync(file, content, 'utf8');
