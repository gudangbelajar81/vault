﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/IntelligenceHub.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('Facebook')) {
  // Add Facebook and Megaphone icons from lucide-react
  content = content.replace("Video, MapPin, Camera, PlaySquare", "Video, MapPin, Camera, PlaySquare, Facebook, Megaphone");
  
  // Add activeTab types
  content = content.replace("<'tiktok' | 'instagram' | 'maps' | 'youtube'>", "<'tiktok' | 'instagram' | 'maps' | 'youtube' | 'facebook' | 'fbads'>");
  
  // Add the tabs in the UI
  const newTabs = `<TabButton active={activeTab === 'facebook'} onClick={() => setActiveTab('facebook')} icon={<Facebook size={16} />} label="Facebook Pro" activeColor="text-blue-600" activeBorder="border-blue-600" />
        <TabButton active={activeTab === 'fbads'} onClick={() => setActiveTab('fbads')} icon={<Megaphone size={16} />} label="FB Ads" activeColor="text-orange-500" activeBorder="border-orange-500" />
      </div>`;
  
  content = content.replace("</div>\n\n      {/* Search Bar */}", newTabs + "\n\n      {/* Search Bar */}");
}

fs.writeFileSync(file, content, 'utf8');
