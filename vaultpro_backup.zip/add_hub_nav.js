﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/DashboardLayout.tsx';
let content = fs.readFileSync(file, 'utf8');

if (!content.includes('Radar,')) {
  content = content.replace("Library, RefreshCw, LayoutPanelLeft }", "Library, RefreshCw, LayoutPanelLeft, Radar }");
}

if (!content.includes('to: \'/intelligence\'')) {
  const newNavItem = `  { to: '/intelligence', icon: Radar, label: 'Radar Tren', activeColor: 'text-teal-400', glow: 'shadow-teal-500/20' },
  { to: '/workspace',`;
  content = content.replace("{ to: '/workspace',", newNavItem);
}

fs.writeFileSync(file, content, 'utf8');
