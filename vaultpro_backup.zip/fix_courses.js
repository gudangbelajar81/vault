﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/Courses.tsx';
let content = fs.readFileSync(file, 'utf8');

// Fix duplicate extraLinks
content = content.replace(
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n        extraLinks: [{ id: Date.now().toString() + 'e1', name: '', url: '' }],\n      extraLinks: [{ id: Date.now().toString() + 'e1', name: '', url: '' }],",
  "communities: [{ id: Date.now().toString() + 'c1', url: '' }],\n      extraLinks: [{ id: Date.now().toString() + 'e1', name: '', url: '' }],"
);

// Fix missing eLinks definition in handleEdit
// Wait, I did replace this:
// "const comms = dec.communities && dec.communities.length > 0 ? dec.communities : [{ id: Date.now().toString() + 'c1', url: '' }];"
// But maybe it wasn't replaced because the match string wasn't exact? Let's check handleEdit in the file.
