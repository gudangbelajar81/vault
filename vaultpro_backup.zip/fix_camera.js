﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/components/SmartNotepad.tsx';
let content = fs.readFileSync(file, 'utf8');

// Replace the single Image input with two inputs (one for gallery, one for camera)
const oldInput = `<input 
            type="file" 
            accept="image/*" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleImageUpload} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessingImage}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg text-xs font-bold transition-colors shadow-sm disabled:opacity-50"
          >
            {isProcessingImage ? <Loader2 size={14} className="animate-spin" /> : <ImageIcon size={14} />}
            <span className="hidden sm:inline">Foto Pintar</span>
          </button>`;

const newInput = `
          {/* Gallery Input */}
          <input 
            type="file" 
            accept="image/*" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleImageUpload} 
          />
          {/* Camera Input */}
          <input 
            type="file" 
            accept="image/*" 
            capture="environment"
            id="cameraInput"
            className="hidden" 
            onChange={handleImageUpload} 
          />
          
          <div className="flex bg-indigo-500 rounded-lg overflow-hidden shadow-sm disabled:opacity-50">
            <button 
              onClick={() => document.getElementById('cameraInput')?.click()}
              disabled={isProcessingImage}
              className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-indigo-600 text-white text-xs font-bold transition-colors border-r border-indigo-400/30"
              title="Kamera Langsung"
            >
              {isProcessingImage ? <Loader2 size={14} className="animate-spin" /> : <ImageIcon size={14} />}
              <span className="hidden sm:inline">Kamera</span>
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessingImage}
              className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-indigo-600 text-white text-xs font-bold transition-colors"
              title="Pilih dari Galeri"
            >
              <span className="hidden sm:inline">Galeri</span>
            </button>
          </div>
`;

content = content.replace(oldInput, newInput);
fs.writeFileSync(file, content, 'utf8');
