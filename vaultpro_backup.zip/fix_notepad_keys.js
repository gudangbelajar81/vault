﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/components/SmartNotepad.tsx';
let content = fs.readFileSync(file, 'utf8');

// Replace the getAiKeys logic
const oldFetch = `      if (res.data.success) {
        for (const item of res.data.data) {
          if (item.type === 'api') {
            try {
              if (!masterPassword) return { groqKey: '', openRouterKey: '', geminiKey: '' };
              const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));
              if (item.title === 'Groq API Key (Omni Router)') groqKey = dec.keys[0];
              if (item.title === 'OpenRouter API Key') openRouterKey = dec.keys[0];
              if (item.title === 'Gemini API Key') geminiKey = dec.keys[0];
            } catch (e) {}
          }
        }
      }`;

const newFetch = `      if (res.data.success) {
        for (const item of res.data.data) {
          if (item.type === 'api' || item.type === 'api_key') {
            try {
              if (!masterPassword) return { groqKey: '', openRouterKey: '', geminiKey: '' };
              const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));
              
              let extractedKey = '';
              if (dec.keys && dec.keys.length > 0) extractedKey = dec.keys[0];
              else if (dec.accounts && dec.accounts[0] && dec.accounts[0].apis && dec.accounts[0].apis[0]) extractedKey = dec.accounts[0].apis[0].key;
              
              if (item.title === 'Groq API Key (Omni Router)') groqKey = extractedKey;
              if (item.title === 'OpenRouter API Key') openRouterKey = extractedKey;
              if (item.title === 'Gemini API Key') geminiKey = extractedKey;
            } catch (e) {}
          }
        }
      }`;

content = content.replace(oldFetch, newFetch);
fs.writeFileSync(file, content, 'utf8');
