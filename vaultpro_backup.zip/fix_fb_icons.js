﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/IntelligenceHub.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("Video, MapPin, Camera, PlaySquare, Facebook, Megaphone", "Video, MapPin, Camera, PlaySquare, Users, Megaphone");
content = content.replace("<Facebook size={16} />", "<Users size={16} />");

fs.writeFileSync(file, content, 'utf8');
