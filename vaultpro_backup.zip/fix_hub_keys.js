﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/IntelligenceHub.tsx';
let content = fs.readFileSync(file, 'utf8');

// Replace the key fetching logic
const oldFetch = `          for (const item of res.data.data) {
            if (item.type === 'api' && item.title.toLowerCase().includes('apify')) {
              if (!masterPassword) return;
              const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));
              setApifyKey(dec.keys[0]);
              break;
            }
          }`;

const newFetch = `          for (const item of res.data.data) {
            if ((item.type === 'api' || item.type === 'api_key') && item.title.toLowerCase().includes('apify')) {
              if (!masterPassword) return;
              const dec = JSON.parse(await decryptData(item.encryptedData, masterPassword));
              // Support both structure formats (Settings vs ApiKeys page)
              if (dec.keys && dec.keys.length > 0) {
                 setApifyKey(dec.keys[0]);
              } else if (dec.accounts && dec.accounts[0] && dec.accounts[0].apis && dec.accounts[0].apis[0]) {
                 setApifyKey(dec.accounts[0].apis[0].key);
              }
              break;
            }
          }`;

content = content.replace(oldFetch, newFetch);
fs.writeFileSync(file, content, 'utf8');
