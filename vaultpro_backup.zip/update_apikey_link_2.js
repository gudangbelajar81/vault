﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/ApiKeys.tsx';
let content = fs.readFileSync(file, 'utf8');

const oldFormInput = `                        {acc.apis.map((api, apiIdx) => (
                          <div key={api.id} className="flex flex-col md:flex-row gap-1 items-end">
                            <div className="col-span-5 md:col-span-5">
                                  <input type="text" placeholder="Nama API"
                                  value={api.name}
                                onChange={(e) => {
                                  const newAccs = [...formData.accounts];
                                  newAccs[accIdx].apis[apiIdx].name = e.target.value;
                                  setFormData({...formData, accounts: newAccs});
                                }}
                                
                                className="w-full bg-surface/50 border border-border rounded-lg px-2 py-1 text-[11px] text-text-primary focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                              />
                            </div>
                            <div className="col-span-12 md:col-span-6">
                              <div className="flex gap-1">
                                <div className="relative flex-1">
                                  <input 
                                    type={formShowApi[api.id] === false ? "password" : "text"} 
                                    placeholder="API Key"
                                  value={api.key}
                                    onChange={(e) => {
                                      const newAccs = [...formData.accounts];
                                      newAccs[accIdx].apis[apiIdx].key = e.target.value;
                                      setFormData({...formData, accounts: newAccs});
                                    }}
                                    
                                    className="w-full bg-surface/50 border border-border rounded-lg px-2 py-1.5 pr-7 text-xs text-text-primary font-mono focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                                  />
                                  <button 
                                    type="button"
                                    onClick={() => setFormShowApi({...formShowApi, [api.id]: formShowApi[api.id] === false ? true : false})}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
                                  >
                                    {formShowApi[api.id] === false ? <Eye size={12} /> : <EyeOff size={12} />}
                                  </button>
                                </div>
                                <button type="button" onClick={() => copyToClipboard(api.key, 'API Key')} className="p-1.5 bg-surface border border-border rounded-lg text-text-muted hover:text-primary transition-colors">
                                  <Copy size={12} />
                                </button>
                                <button type="button" onClick={() => removeApiFromAccount(acc.id, api.id)} className="p-1.5 bg-rose-500/10 border border-rose-500/20 rounded-lg text-rose-500 hover:bg-rose-500 hover:text-white transition-colors">
                                  <X size={12} />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}`;

const newFormInput = `                        {acc.apis.map((api, apiIdx) => (
                          <div key={api.id} className="flex flex-col gap-1 items-end bg-black/10 dark:bg-white/5 p-2 rounded-lg border border-border/50">
                            <div className="w-full flex gap-1">
                              <input type="text" placeholder="Nama API"
                                value={api.name}
                                onChange={(e) => {
                                  const newAccs = [...formData.accounts];
                                  newAccs[accIdx].apis[apiIdx].name = e.target.value;
                                  setFormData({...formData, accounts: newAccs});
                                }}
                                className="flex-1 bg-surface/50 border border-border rounded-lg px-2 py-1.5 text-[11px] text-text-primary focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                              />
                              <input type="url" placeholder="Link Web (Opsional)"
                                value={api.url || ''}
                                onChange={(e) => {
                                  const newAccs = [...formData.accounts];
                                  newAccs[accIdx].apis[apiIdx].url = e.target.value;
                                  setFormData({...formData, accounts: newAccs});
                                }}
                                className="flex-1 bg-surface/50 border border-border rounded-lg px-2 py-1.5 text-[11px] text-text-primary focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                              />
                            </div>
                            <div className="w-full flex gap-1">
                                <div className="relative flex-1">
                                  <input 
                                    type={formShowApi[api.id] === false ? "password" : "text"} 
                                    placeholder="API Key rahasia..."
                                    value={api.key}
                                    onChange={(e) => {
                                      const newAccs = [...formData.accounts];
                                      newAccs[accIdx].apis[apiIdx].key = e.target.value;
                                      setFormData({...formData, accounts: newAccs});
                                    }}
                                    className="w-full bg-surface/50 border border-border rounded-lg px-2 py-1.5 pr-7 text-xs text-text-primary font-mono focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                                  />
                                  <button 
                                    type="button"
                                    onClick={() => setFormShowApi({...formShowApi, [api.id]: formShowApi[api.id] === false ? true : false})}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-primary"
                                  >
                                    {formShowApi[api.id] === false ? <Eye size={12} /> : <EyeOff size={12} />}
                                  </button>
                                </div>
                                <button type="button" onClick={() => copyToClipboard(api.key, 'API Key')} className="p-1.5 bg-surface border border-border rounded-lg text-text-muted hover:text-primary transition-colors">
                                  <Copy size={12} />
                                </button>
                                <button type="button" onClick={() => removeApiFromAccount(acc.id, api.id)} className="p-1.5 bg-rose-500/10 border border-rose-500/20 rounded-lg text-rose-500 hover:bg-rose-500 hover:text-white transition-colors">
                                  <X size={12} />
                                </button>
                            </div>
                          </div>
                        ))}`;

content = content.replace(oldFormInput, newFormInput);
fs.writeFileSync(file, content, 'utf8');
