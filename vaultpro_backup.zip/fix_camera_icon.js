﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/components/SmartNotepad.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("import { Save, Mic, Image as ImageIcon, CheckCircle2, Trash2, StopCircle, Loader2 } from 'lucide-react';", "import { Save, Mic, Image as ImageIcon, Camera, CheckCircle2, Trash2, StopCircle, Loader2 } from 'lucide-react';");

content = content.replace("<ImageIcon size={14} />\n              <span className=\"hidden sm:inline\">Kamera</span>", "<Camera size={14} />\n              <span className=\"hidden sm:inline\">Kamera</span>");

fs.writeFileSync(file, content, 'utf8');
