﻿const fs = require('fs');
const file = 'F:/BLUEPRINT APLIKASI/vaultpro/frontend/src/pages/IntelligenceHub.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace("Youtube, MapPin, Instagram, PlaySquare", "Video, MapPin, Camera, PlaySquare");
content = content.replace("<Youtube size={16} />", "<Video size={16} />");
content = content.replace("<Instagram size={16} />", "<Camera size={16} />");

fs.writeFileSync(file, content, 'utf8');
